g++ run_energy_reconstruction.cc -o run_energy_reconstruction.exe `root-config --cflags --libs`
